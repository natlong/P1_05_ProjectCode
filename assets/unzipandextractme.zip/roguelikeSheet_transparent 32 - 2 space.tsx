<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="roguelikeSheet_transparent 32 - 2 space" tilewidth="32" tileheight="32" spacing="2" tilecount="1767" columns="57">
 <image source="roguelikeSheet_transparent 32 - 2 space.png" width="1936" height="1052"/>
</tileset>
